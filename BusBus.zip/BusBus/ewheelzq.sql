-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 05, 2017 at 10:18 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ewheelz`
--

-- --------------------------------------------------------

--
-- Table structure for table `busmaster`
--

CREATE TABLE IF NOT EXISTS `busmaster` (
  `BusId` varchar(20) NOT NULL,
  `BusType` varchar(50) DEFAULT NULL,
  `BusNumber` varchar(20) DEFAULT NULL,
  `Capacity` int(3) DEFAULT '0',
  `TravelsId` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`BusId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `busmaster`
--

INSERT INTO `busmaster` (`BusId`, `BusType`, `BusNumber`, `Capacity`, `TravelsId`) VALUES
('B3', 'Sleeper', 'AP 12 222', 40, 'T2'),
('B4', 'Sleeper', 'AP 1900', 40, 'T3'),
('B5', 'AC', 'AP 34322', 40, 'T3'),
('B6', 'AC', 'AP 1981', 40, 'T2'),
('B7', 'NonAC', '143', 40, 'T4'),
('B8', 'AC', 'AP 4091', 40, 'T6'),
('B9', 'Sleeper', 'AP 1900', 40, 'T3'),
('B10', 'AC', 'R1', 40, 'T6'),
('B11', 'AC', 'AP 1981', 40, 'T6'),
('B12', 'AC', '22222', 40, 'T7');

-- --------------------------------------------------------

--
-- Table structure for table `customermaster`
--

CREATE TABLE IF NOT EXISTS `customermaster` (
  `CustomerId` varchar(20) NOT NULL,
  `CustomerName` varchar(80) NOT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `Address` tinytext NOT NULL,
  `Location` varchar(80) NOT NULL,
  `email` varchar(80) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL COMMENT 'Male/Female',
  PRIMARY KEY (`CustomerId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customermaster`
--

INSERT INTO `customermaster` (`CustomerId`, `CustomerName`, `PhoneNumber`, `Address`, `Location`, `email`, `Gender`) VALUES
('C2', 'srinivas', '9999999999', 'Ameerpet', 'Hyderabad', 'kalyan@gmail.com', 'Male'),
('C3', 'Raj', '9909909900', 'Dilshuknagar', 'Hyderabad', 'Raj001@yahoo.com', 'Male'),
('C4', 'Rani', '9440944000', 'Ranigunz', 'Hyderabad', 'Rani07@gmail.com', 'Female'),
('C5', 'Rahul', '9999999999', 'Bangalore', 'Hyderabad', 'RahulM@rediff.com', 'Male'),
('C6', 'Suresh', '9290125200', 'Gachibowli', 'Hyderabad', 'Suresh@zapakmail.com', 'Male'),
('C7', 'giri', '2342342344', 'asdf', 'Hyd', 'Giri@rediffmail.com', 'Male'),
('C8', 'fff', '9491348934', 'fdgf', 'fgfd', 'v.rameshreddy@ymail.com', 'Male'),
('C9', 'fsdf', '9491348934', 'cvbcxv', 'vcvc', 'v.rameshreddy@ymail.com', 'Male'),
('C10', 'ff', '9491348934', 'dcvcxcv', 'vcvc', 'v.rameshreddy@ymail.com', 'Male'),
('C11', 'hgh', '9491348934', 'hhh', 'ggg', 'v.rameshreddy@ymail.com', 'Female'),
('C12', 'xczx', '9491348934', 'vdvx', 'fdgdfg', 'v.rameshreddy@ymail.com', 'Male'),
('C13', 'hfg', '9491348934', 'efesd', 'fgfgfd', 'v.rameshreddy@ymail.com', 'Male'),
('C14', 'asdf', '1234567890', 'hyd', 'tarnaka', 'asdf@gmail.com', 'Female'),
('C15', 'fdgff', '1234567800', 'Hyderabad', 'Hyderabad', 'asdf@gmail.com', 'Male'),
('C16', 'ramesh', '9491348934', 'vij', 'hyd', 'rameshv.coign@gmail.com', 'Male'),
('C17', 'bhavani', '9908766543', 'tarnaka', 'hyderabad', 'bhavanib.coign@gmail.com', 'Female');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `FId` int(10) NOT NULL AUTO_INCREMENT,
  `UserID` varchar(100) DEFAULT NULL,
  `Feedback` text,
  `DateSubmitted` date DEFAULT NULL,
  PRIMARY KEY (`FId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`FId`, `UserID`, `Feedback`, `DateSubmitted`) VALUES
(1, 'kalyansrinivas@rediffmail.com', 'Hi, Portal is good. Services of Ganga Travels is too good.Thanks', '2007-11-19'),
(2, 'Rajesh@gmail.com', 'Good website. Services are superb. ', '2007-11-19'),
(3, 'RajuSrivastav@Zapakmail.com', 'One stop shop for booking bus tickets online anywhere in India.', '2007-11-19'),
(7, 'raj@raj.com', 'Good site..worth of it', '2007-11-19'),
(8, 'rameshv.coign@gmail.com', 'hi', '2015-12-31');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `userid` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `auth` int(5) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`userid`, `password`, `auth`) VALUES
('admin', 'admin', 0);

-- --------------------------------------------------------

--
-- Table structure for table `paymentdetails`
--

CREATE TABLE IF NOT EXISTS `paymentdetails` (
  `PaymentId` varchar(20) DEFAULT NULL,
  `CustomerId` varchar(20) DEFAULT NULL,
  `PaymentMode` varchar(25) DEFAULT NULL,
  `BankName` varchar(30) DEFAULT NULL,
  `CardNo` varchar(25) DEFAULT NULL,
  `NetAmount` int(10) DEFAULT NULL,
  `PaymentStatus` varchar(20) DEFAULT NULL,
  `TicketId` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paymentdetails`
--

INSERT INTO `paymentdetails` (`PaymentId`, `CustomerId`, `PaymentMode`, `BankName`, `CardNo`, `NetAmount`, `PaymentStatus`, `TicketId`) VALUES
('P1', 'C5', 'Credit', 'ICICI', '4565456456454565', 2600, 'Made', ''),
('P3', 'C7', 'Credit', 'SBI', '9090909090909090', 1200, 'Made', 'T-9'),
('P2', 'C6', 'Credit', 'ICICI', '9909990999099909', 1950, 'Made', 'T-8'),
('P4', 'C11', 'Debit', 'grd', '2123456789876543', 600, 'Made', 'T-13'),
('P5', 'C12', 'Debit', 'dfdf', '1111111111111111', 600, 'Made', 'T-14'),
('P6', 'C13', 'Credit', 'dfdf', '5123456789123456', 1200, 'Made', 'T-15'),
('P7', 'C14', 'Debit', 'sbh', '1478523690123456', 3000, 'Made', 'T-17'),
('P8', 'C16', 'Debit', 'SBI', '1234123412341212', 900, 'Made', 'T-20'),
('P9', 'C17', 'Credit', 'SBI', '1234123412341212', 1600, 'Made', 'T-22'),
('P10', 'C17', 'Credit', 'SBI', '1234123412341212', 1600, 'Made', 'T-22');

-- --------------------------------------------------------

--
-- Table structure for table `routemap`
--

CREATE TABLE IF NOT EXISTS `routemap` (
  `RouteId` varchar(20) NOT NULL,
  `PickupPoint` varchar(50) NOT NULL,
  `Fare` int(3) DEFAULT '0',
  PRIMARY KEY (`RouteId`,`PickupPoint`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `routemap`
--

INSERT INTO `routemap` (`RouteId`, `PickupPoint`, `Fare`) VALUES
('R1', 'Ameerpet', 0),
('R1', 'KPHB', 0),
('R1', 'Panjagutta', 0),
('R2', 'Ameerpet', 0),
('R2', 'KPHB', 0),
('R2', 'ggg', 0),
('R3', 'kukatpally', 0),
('R9', 'ECIL', 0),
('R9', 'MGBS', 0),
('R9', 'MGBS1', 0),
('R9', 'sdf', 0),
('R9', 'sdf1', 0),
('R10', 'nacharam', 0),
('R10', 'tarnaka', 0),
('R12', 'Tarnaka', 0),
('R13', 'lbnagar', 0),
('R11', 'lbnagar', 0),
('R15', 'tarnaka', 0),
('R15', 'habsiguda', 0),
('R15', 'lbNagar', 0),
('R18', 'tarnaka', 0),
('R18', 'habsiguda', 0),
('R19', 'tarnaka', 0);

-- --------------------------------------------------------

--
-- Table structure for table `routemaster`
--

CREATE TABLE IF NOT EXISTS `routemaster` (
  `RouteId` varchar(20) NOT NULL,
  `rFrom` varchar(50) NOT NULL,
  `rTo` varchar(50) NOT NULL,
  `TravelsId` varchar(20) NOT NULL,
  `BusId` varchar(20) NOT NULL,
  `Departure` time DEFAULT NULL,
  `Arrival` time DEFAULT NULL,
  `Fare` int(10) NOT NULL DEFAULT '0',
  `JDate` date DEFAULT NULL,
  `Availability` int(3) DEFAULT NULL,
  PRIMARY KEY (`RouteId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `routemaster`
--

INSERT INTO `routemaster` (`RouteId`, `rFrom`, `rTo`, `TravelsId`, `BusId`, `Departure`, `Arrival`, `Fare`, `JDate`, `Availability`) VALUES
('R1', 'Hyderabad', 'Bangalore', 'T1', 'B1', '19:00:00', '08:00:00', 650, '2015-12-30', 25),
('R2', 'Hyderabad', 'Bangalore', 'T2', 'B3', '21:00:00', '09:00:00', 600, '2016-01-02', 40),
('R3', 'Hyderabad', 'Pune', 'T3', 'B3', '21:00:00', '09:00:00', 600, '2007-11-20', 40),
('R4', 'Hyderabad', 'Chennai', 'T1', 'B1', '19:00:00', '08:00:00', 450, '2007-11-12', 40),
('R5', 'Hyderabad', 'Chennai', 'T1', 'B2', '18:00:00', '19:00:00', 450, '2007-11-19', 40),
('R6', 'Hyderabad', 'Nellore', 'T2', 'B3', '08:00:00', '08:30:00', 600, '2007-11-18', 40),
('R7', 'Hyderabad', 'Ongole', 'T2', 'B3', '11:00:00', '19:00:00', 234, '2007-11-20', 40),
('R17', 'Hyderabad', 'Vijayanagaram', 'T6', 'B6', '22:00:00', '05:00:00', 700, '2017-07-07', 40),
('R9', 'Hyderabad', 'Nasik', 'T3', 'B4', '19:00:00', '15:00:00', 980, '2007-11-20', 40),
('R10', 'Hyderabad', 'Bangalore', 'T5', 'B3', '10:00:00', '08:00:00', 1500, '2016-07-09', 38),
('R12', 'Hyderabad', 'Bangalore', 'T3', 'B4', '09:30:00', '13:30:00', 5000, '2016-07-07', 40),
('R11', 'Hyderabad', 'Kurnool', 'T6', 'B8', '06:00:00', '09:00:00', 2000, '2016-07-31', 40),
('R13', 'Kurnool', 'Hyderabad', 'T2', 'B3', '18:00:00', '20:00:00', 500, '2017-07-03', 40),
('R14', 'Chennai', 'Hyderabad', 'T6', 'B8', '07:00:00', '09:00:00', 600, '2017-07-03', 40),
('R15', 'Hyderabad', 'Vijayawada', 'T2', 'B6', '22:00:00', '05:00:00', 450, '2017-07-05', 38),
('R18', 'Hyderabad', 'Tirupathi', 'T3', 'B5', '22:00:00', '05:00:00', 800, '2017-07-08', 38),
('R19', 'Ahmedabad', 'Tirupathi', 'T2', 'B3', '22:00:00', '06:00:00', 5000, '2017-07-09', 40);

-- --------------------------------------------------------

--
-- Table structure for table `ticketdetails`
--

CREATE TABLE IF NOT EXISTS `ticketdetails` (
  `TicketId` varchar(20) NOT NULL,
  `RouteId` varchar(20) NOT NULL,
  `CustomerId` varchar(20) NOT NULL,
  `rFrom` varchar(50) DEFAULT NULL,
  `rTo` varchar(50) DEFAULT NULL,
  `JourneyDate` date NOT NULL,
  `StartTime` time DEFAULT NULL,
  `ReachTime` time DEFAULT NULL,
  `Seats` varchar(255) DEFAULT NULL,
  `BoardingPoint` varchar(50) DEFAULT NULL,
  `NetAmount` int(10) DEFAULT NULL,
  `Status` varchar(20) DEFAULT NULL,
  `PaymentId` varchar(20) DEFAULT NULL,
  `BusId` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`TicketId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticketdetails`
--

INSERT INTO `ticketdetails` (`TicketId`, `RouteId`, `CustomerId`, `rFrom`, `rTo`, `JourneyDate`, `StartTime`, `ReachTime`, `Seats`, `BoardingPoint`, `NetAmount`, `Status`, `PaymentId`, `BusId`) VALUES
('T-2', 'R1', '', 'Hyderabad', 'Bangalore', '2007-11-17', '19:00:00', '08:00:00', 'A3,B3,C3,D3', 'KPHB', 2600, 'Progress', '', 'B1'),
('T-6', 'R2', '', 'Hyderabad', 'Bangalore', '2007-11-17', '21:00:00', '09:00:00', 'A5,B5,B6,A6', 'KPHB', 2400, 'Progress', '', 'B3'),
('T-7', 'R1', '', 'Hyderabad', 'Bangalore', '2007-11-19', '19:00:00', '08:00:00', 'A2,B2,C2', 'Ameerpet', 1950, 'Progress', '', 'B1'),
('T-8', 'R1', 'C6', 'Hyderabad', 'Bangalore', '2007-11-19', '19:00:00', '08:00:00', 'A2,B2,C2', 'Ameerpet', 1950, 'Booked', 'P2', 'B1'),
('T-9', 'R2', 'C7', 'Hyderabad', 'Bangalore', '2007-11-20', '21:00:00', '09:00:00', 'A1,B1', 'Ameerpet', 1200, 'Booked', 'P3', 'B3'),
('T-16', 'R2', '', 'Hyderabad', 'Bangalore', '2016-01-02', '21:00:00', '09:00:00', 'A7,B7', 'Ameerpet', 1200, 'Progress', '', 'B3'),
('T-15', 'R2', 'C13', 'Hyderabad', 'Bangalore', '2015-12-31', '21:00:00', '09:00:00', 'B5,B6', 'Ameerpet', 1200, 'Booked', 'P6', 'B3'),
('T-14', 'R2', 'C12', 'Hyderabad', 'Bangalore', '2015-12-30', '21:00:00', '09:00:00', 'B3', 'Ameerpet', 600, 'Booked', 'P5', 'B3'),
('T-13', 'R2', 'C11', 'Hyderabad', 'Bangalore', '2015-12-30', '21:00:00', '09:00:00', 'A5', 'Ameerpet', 600, 'Booked', 'P4', 'B3'),
('T-17', 'R10', 'C14', 'Hyderabad', 'Bangalore', '2016-04-15', '10:00:00', '08:00:00', 'A1,A2', 'tarnaka', 3000, 'Booked', 'P7', 'B3'),
('T-18', 'R10', '', 'Hyderabad', 'Bangalore', '2016-04-15', '10:00:00', '08:00:00', 'C5,C6', 'tarnaka', 3000, 'Progress', '', 'B3'),
('T-19', 'R12', '', 'Hyderabad', 'Bangalore', '2016-04-25', '10:00:00', '08:00:00', 'B2,B3', 'Tarnaka', 3000, 'Progress', '', 'B3'),
('T-20', 'R15', 'C16', 'Hyderabad', 'Vijayawada', '2017-07-05', '22:00:00', '05:00:00', 'A1,B1', 'tarnaka', 900, 'Booked', 'P8', 'B6'),
('T-21', 'R15', '', 'Hyderabad', 'Vijayawada', '2017-07-05', '22:00:00', '05:00:00', 'A2,B2,A3', 'habsiguda', 1350, 'Progress', '', 'B6'),
('T-22', 'R18', 'C17', 'Hyderabad', 'Tirupathi', '2017-07-08', '22:00:00', '05:00:00', 'A1,A2', 'habsiguda', 1600, 'Booked', 'P10', 'B5');

-- --------------------------------------------------------

--
-- Table structure for table `travelsmaster`
--

CREATE TABLE IF NOT EXISTS `travelsmaster` (
  `TravelsId` varchar(20) NOT NULL,
  `Travels` varchar(80) DEFAULT NULL,
  `Location` varchar(80) DEFAULT NULL,
  `Address` tinytext,
  `AgentName` varchar(80) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`TravelsId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `travelsmaster`
--

INSERT INTO `travelsmaster` (`TravelsId`, `Travels`, `Location`, `Address`, `AgentName`, `PhoneNumber`) VALUES
('T2', 'Raj Travels', 'Bangalore', 'Koramangala,Bangalore', 'Srinivas', '9298892222'),
('T3', 'Pran Travels', 'Hyderabad', 'Lower Tankbund', 'Pravan', '98989898980'),
('T4', 'T4', 'Vijayawada', 'Vijayawada', 'Kamineni', '9640989798'),
('T5', 'kesineni', 'Hyderabad', 'hyderabad', 'cool', '9491348934'),
('T6', 'asdf', 'Hyderabad', 'lbnagar', 'qwerty', '1234567890'),
('T7', 'bhavani', 'Hyderabad', 'hyderabad', 'bhavani', '9908766543');
